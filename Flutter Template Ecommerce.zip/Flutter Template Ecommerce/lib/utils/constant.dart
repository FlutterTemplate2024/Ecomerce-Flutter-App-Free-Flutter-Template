// ignore_for_file: constant_identifier_names

class AppConstant {
  static const String THEME = 'theme';
  static const String COUNTRY_CODE = 'country_code';
  static const String LANGUAGE_CODE = 'language_code';
  static const String userId = 'user_id';
  static const String getStarted = 'getStarted';
  static const String cart = "CART_SESSION";
  static const String wishlistProducts = "CS_WISHLIST_PRODUCTS";

}
